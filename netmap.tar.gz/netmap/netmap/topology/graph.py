from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any


@dataclass
class Node:
    id: str
    kind: str          # root/section/internet/listener/interface/process/note
    label: str
    meta: str = ""
    style: str = ""
    ref: Any = None
    children: list["Node"] = field(default_factory=list)

    def add(self, node: "Node") -> "Node":
        self.children.append(node)
        return node


@dataclass
class ListenerGroup:
    """Несколько сокетов одного порта (v4+v6, воркеры nginx) сводим в один узел."""
    key: str
    proto: str
    port: int
    scope: str                       # any / loopback / addr
    where: str = ""                  # имя интерфейса для scope=addr
    addrs: list[str] = field(default_factory=list)
    ips: set[str] = field(default_factory=set)
    pids: list[int] = field(default_factory=list)
    established: int = 0
    remotes: list[str] = field(default_factory=list)
    upstreams: list[str] = field(default_factory=list)
