"""Строим дерево топологии из Snapshot.

Связи между процессами берём ТОЛЬКО из реально наблюдаемых соединений:
если у соединения известен PID клиента и remote-адрес совпадает с локальным
слушающим сокетом, значит процесс туда ходит. Ничего не додумываем.
"""
from __future__ import annotations

from netmap.snapshot import Snapshot
from netmap.topology.graph import ListenerGroup, Node
from netmap.util import fmt_addr, is_loopback, is_public, is_wildcard

MAX_DEPTH = 6


def _proc_label(g: ListenerGroup, snap: Snapshot) -> tuple[str, str]:
    if not g.pids:
        return "owner unknown", "dim"
    names = []
    for pid in g.pids:
        p = snap.processes.get(pid)
        n = p.name if p else f"pid {pid}"
        if n not in names:
            names.append(n)
    return ", ".join(names[:2]) + ("…" if len(names) > 2 else ""), "bold"


def build_groups(snap: Snapshot):
    local_ips = {a.split("/")[0] for i in snap.interfaces for a in i.ipv4 + i.ipv6}
    iface_by_ip = {a.split("/")[0]: i.name for i in snap.interfaces for a in i.ipv4 + i.ipv6}

    groups: dict[str, ListenerGroup] = {}
    for s in snap.listeners:
        if is_wildcard(s.ip):
            scope, where = "any", ""
        elif is_loopback(s.ip):
            scope, where = "loopback", ""
        else:
            scope, where = "addr", iface_by_ip.get(s.ip, s.ip)
        key = f"{s.proto}:{s.port}:{scope}:{where}"
        g = groups.setdefault(key, ListenerGroup(key, s.proto, s.port, scope, where))
        addr = fmt_addr(s.ip, s.port)
        if addr not in g.addrs:
            g.addrs.append(addr)
        g.ips.add(s.ip)
        if s.pid and s.pid not in g.pids:
            g.pids.append(s.pid)

    by_port: dict[tuple[str, int], list[ListenerGroup]] = {}
    for g in groups.values():
        g.pids.sort()
        by_port.setdefault((g.proto, g.port), []).append(g)

    def match(proto: str, ip: str, port: int) -> ListenerGroup | None:
        for g in by_port.get((proto, port), []):
            if ip in g.ips or (g.scope == "any" and ip in local_ips):
                return g
        return None

    upstream: dict[str, dict[str, ListenerGroup]] = {k: {} for k in groups}
    outbound: dict[int, set[str]] = {}
    unowned_out = 0
    for c in snap.connections:
        if c.state not in ("ESTABLISHED", "CONNECTED"):
            continue
        inbound = match(c.proto, c.lip, c.lport)
        if inbound:  # к нам пришли
            inbound.established += 1
            if len(inbound.remotes) < 50:
                inbound.remotes.append(fmt_addr(c.rip, c.rport))
            continue
        target = match(c.proto, c.rip, c.rport)
        if target:  # мы пошли в другой локальный сервис
            if c.pid:
                for g in groups.values():
                    if c.pid in g.pids and g.key != target.key:
                        upstream[g.key][target.key] = target
            continue
        if is_loopback(c.rip):
            continue
        if c.pid:
            outbound.setdefault(c.pid, set()).add(fmt_addr(c.rip, c.rport))
        else:
            unowned_out += 1

    for k, ups in upstream.items():
        groups[k].upstreams = [f"{u.addrs[0]}/{u.proto}" for u in ups.values()]
    return groups, upstream, outbound, unowned_out


def build_topology(snap: Snapshot) -> Node:
    groups, upstream, outbound, unowned_out = build_groups(snap)

    facing = {
        i.name for i in snap.interfaces
        if i.kind != "loopback" and (i.is_default or any(is_public(a.split("/")[0]) for a in i.ipv4 + i.ipv6))
    }
    face_ifaces = [i for i in snap.interfaces if i.name in facing]

    def listener_node(g: ListenerGroup, parent_id: str, seen: frozenset, depth: int) -> Node:
        pname, pstyle = _proc_label(g, snap)
        p = snap.processes.get(g.pids[0]) if g.pids else None
        meta = []
        if g.pids:
            meta.append(f"PID {g.pids[0]}" + (f" +{len(g.pids) - 1}" if len(g.pids) > 1 else ""))
        if p and p.service:
            meta.append(p.service)
        if g.established:
            meta.append(f"{g.established} conn")
        n = Node(f"{parent_id}>{g.key}", "listener", f":{g.port}/{g.proto}  {pname}", " · ".join(meta),
                 "cyan" if g.scope == "any" else "green", g)
        if depth < MAX_DEPTH:
            for tgt in sorted(upstream[g.key].values(), key=lambda x: x.port):
                if tgt.key not in seen:
                    n.add(listener_node(tgt, n.id, seen | {g.key}, depth + 1))
        return n

    nested = {t for ups in upstream.values() for t in ups}
    sg = sorted(groups.values(), key=lambda g: (g.port, g.proto))

    root = Node("root", "root", snap.hostname, "", "bold")

    # --- INTERNET / ALL INTERFACES
    exposed = [g for g in sg if g.scope == "any" or (g.scope == "addr" and g.where in facing)]
    if exposed or face_ifaces:
        if face_ifaces:
            desc = ", ".join(f"{i.name} {(i.ipv4 or i.ipv6 or ['no ip'])[0].split('/')[0]}" for i in face_ifaces)
            gw = next((i.gateway for i in face_ifaces if i.gateway), None)
            meta = f"via {desc}" + (f" · gw {gw}" if gw else "")
            title = "INTERNET"
        else:
            meta, title = "публичный интерфейс не найден", "ALL INTERFACES"
        sec = root.add(Node("sec:inet", "internet", title, meta, "bold magenta", face_ifaces))
        for g in exposed:
            sec.add(listener_node(g, sec.id, frozenset(), 0))
        if not exposed:
            sec.add(Node("inet:none", "note", "нет слушающих сокетов на внешних адресах", "", "dim"))
        sec.add(Node("inet:fw", "note", "bound ≠ reachable: firewall в MVP не проверяется", "", "dim italic"))

    # --- PRIVATE
    priv: dict[str, list[ListenerGroup]] = {}
    for g in sg:
        if g.scope == "addr" and g.where not in facing:
            priv.setdefault(g.where, []).append(g)
    if priv:
        sec = root.add(Node("sec:priv", "section", "PRIVATE NETWORKS", "", "bold yellow"))
        for name, gs in priv.items():
            iface_node = sec.add(Node(f"priv:{name}", "section", name, "", "yellow"))
            for g in gs:
                iface_node.add(listener_node(g, iface_node.id, frozenset(), 0))

    # --- LOCALHOST
    local = [g for g in sg if g.scope == "loopback" and g.key not in nested]
    if local:
        sec = root.add(Node("sec:local", "section", "LOCALHOST ONLY", "доступно только с этой машины", "bold green"))
        for g in local:
            sec.add(listener_node(g, sec.id, frozenset(), 0))

    # --- OUTBOUND
    if outbound or unowned_out:
        sec = root.add(Node("sec:out", "section", "OUTBOUND", "процессы → внешние хосты", "bold blue"))
        for pid, remotes in sorted(outbound.items()):
            p = snap.processes.get(pid)
            sec.add(Node(f"out:{pid}", "process", p.name if p else f"pid {pid}",
                         f"PID {pid} · {len(remotes)} remote", "blue", pid))
        if unowned_out:
            sec.add(Node("out:unk", "note", f"{unowned_out} соединений без известного PID", "", "dim"))

    # --- INTERFACES
    sec = root.add(Node("sec:if", "section", "INTERFACES", "", "bold"))
    for i in snap.interfaces:
        ips = ", ".join(a for a in i.ipv4[:2]) or "no IPv4"
        sec.add(Node(f"if:{i.name}", "interface", i.name, f"{i.state} · {ips}",
                     "green" if i.state == "UP" else "dim", i))
    return root
