from __future__ import annotations
import argparse
import json
import os
import sys
import time

from netmap import __version__

SECTIONS = ["interfaces", "sockets", "connections", "processes", "routes", "dns"]
NOT_IN_MVP = ["containers", "firewall"]


def _parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="netmap", description="Живая карта сети Linux-сервера (read-only).")
    p.add_argument("command", nargs="?", choices=SECTIONS + NOT_IN_MVP,
                   help="без команды открывается TUI")
    p.add_argument("--json", action="store_true", help="вывести данные в JSON")
    p.add_argument("--watch", action="store_true", help="обновлять вывод в терминале без TUI")
    p.add_argument("--export", metavar="FILE", help="сохранить полный снимок в JSON-файл")
    p.add_argument("--interval", type=float, default=2.0, help="период обновления, сек (по умолчанию 2)")
    p.add_argument("--version", action="version", version=f"netmap {__version__}")
    return p


def _section_data(snap, name: str):
    d = snap.to_dict()
    return {"sockets": d["listeners"], "connections": d["connections"]}.get(name, d.get(name))


def _print_table(snap, name: str, console) -> None:
    from rich.table import Table
    from netmap.ui import tables as T
    if name == "dns":
        from netmap.ui.widgets import dns_view
        console.print(dns_view(snap))
        return
    cols, rows = T.TABLES[name](snap)
    t = Table(*cols, box=None, header_style="bold", pad_edge=False)
    for _, cells, _, _ in rows:
        t.add_row(*cells)
    console.print(t)


def _render_once(args, snap, console) -> None:
    if args.json:
        data = snap.to_dict() if not args.command else _section_data(snap, args.command)
        print(json.dumps(data, ensure_ascii=False, indent=2))
    elif args.command:
        _print_table(snap, args.command, console)
    else:
        from netmap.topology.builder import build_topology
        from netmap.ui.topology_view import to_rich_tree
        console.print(to_rich_tree(build_topology(snap)))


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)

    if sys.platform != "linux":
        print("netmap работает только на Linux", file=sys.stderr)
        return 1
    if args.command in NOT_IN_MVP:
        print(f"netmap {args.command}: пока не реализовано (в roadmap). MVP: interfaces, sockets, "
              "connections, processes, routes, dns.", file=sys.stderr)
        return 2

    from rich.console import Console
    from netmap.snapshot import collect_all

    if os.geteuid() != 0:
        print("⚠ запущено без root: PID/процессы чужих пользователей будут N/A. "
              "Для полной картины: sudo netmap", file=sys.stderr)

    # TUI
    if not (args.json or args.watch or args.export or args.command):
        from netmap.app import NetMapApp
        NetMapApp(interval=args.interval).run()
        return 0

    console = Console()
    snap = collect_all()

    if args.export:
        with open(args.export, "w") as f:
            json.dump(snap.to_dict(), f, ensure_ascii=False, indent=2)
        print(f"snapshot saved: {args.export}", file=sys.stderr)
        if not (args.json or args.watch):
            return 0

    if not args.watch:
        _render_once(args, snap, console)
        return 0

    try:
        while True:
            console.clear()
            _render_once(args, snap, console)
            time.sleep(args.interval)
            snap = collect_all(snap)
    except KeyboardInterrupt:
        return 0
