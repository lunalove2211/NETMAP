"""Один снимок состояния сети. Всё остальное (TUI, CLI, JSON) строится на нём."""
from __future__ import annotations
import os
import socket
import time
from dataclasses import asdict, dataclass, field

from netmap.collectors.dns import collect_dns
from netmap.collectors.interfaces import collect_interfaces
from netmap.collectors.processes import collect_processes
from netmap.collectors.routes import collect_routes
from netmap.collectors.sockets import collect_sockets
from netmap.models.connection import Connection
from netmap.models.interface import Interface
from netmap.models.process import Process
from netmap.models.route import Route
from netmap.models.socket import Socket


@dataclass
class Snapshot:
    ts: float
    hostname: str
    is_root: bool
    interfaces: list[Interface]
    routes: list[Route]
    listeners: list[Socket]
    connections: list[Connection]
    processes: dict[int, Process]
    dns: dict
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["processes"] = list(d["processes"].values())
        return d


def collect_all(prev: Snapshot | None = None) -> Snapshot:
    notes: list[str] = []
    routes = collect_routes()
    ifaces = collect_interfaces(routes)
    listeners, conns, err = collect_sockets()
    if err:
        notes.append(err)
    pids = {s.pid for s in listeners + conns if s.pid}
    procs = collect_processes(pids)
    is_root = os.geteuid() == 0
    snap = Snapshot(time.time(), socket.gethostname(), is_root, ifaces, routes, listeners, conns, procs,
                    collect_dns(), notes)

    unknown = sum(1 for s in listeners if s.pid is None and s.proto == "tcp")
    if unknown:
        if is_root:
            notes.append(f"{unknown} TCP-сокетов без PID: принадлежат ядру или другому namespace")
        else:
            notes.append(f"{unknown} TCP-сокетов без PID: запусти через sudo, чтобы видеть процессы других пользователей")

    if prev and snap.ts > prev.ts:
        dt = snap.ts - prev.ts
        old = {i.name: i for i in prev.interfaces}
        for i in snap.interfaces:
            o = old.get(i.name)
            if o and None not in (i.rx_bytes, o.rx_bytes, i.tx_bytes, o.tx_bytes):
                i.rx_rate = max(0, i.rx_bytes - o.rx_bytes) / dt
                i.tx_rate = max(0, i.tx_bytes - o.tx_bytes) / dt
    return snap
