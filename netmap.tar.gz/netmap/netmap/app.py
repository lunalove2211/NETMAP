from __future__ import annotations
import time
from collections import deque

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.css.query import NoMatches
from textual.widgets import DataTable, Footer, Input, Static, TabbedContent, TabPane, Tree

from netmap.snapshot import Snapshot, collect_all
from netmap.topology.builder import build_topology
from netmap.ui import tables as T
from netmap.ui.details import render_details
from netmap.ui.screens import HelpScreen
from netmap.ui.topology_view import node_label
from netmap.ui.widgets import dns_view, events_text, header_text, summary_text
from netmap.util import fmt_addr

TABS = ["topology", "interfaces", "sockets", "connections", "processes", "routes", "dns"]
NARROW = 110


class NetMapApp(App):
    TITLE = "NetMap"
    CSS = """
    #header { height: 1; }
    #main { height: 1fr; }
    #tabs { width: 1fr; }
    #details { width: 46; padding: 0 1; border-left: solid $primary-darken-2; overflow-y: auto; }
    #main.narrow { layout: vertical; }
    #main.narrow #details { display: none; width: 100%; height: 10; border-left: none; border-top: solid $primary-darken-2; }
    #main.narrow.show #details { display: block; }
    #events { height: 2; }
    #summary { height: 1; background: $boost; }
    #filter { display: none; height: 3; }
    #filter.on { display: block; }
    DataTable { height: 1fr; }
    #dns { padding: 1 2; }
    """
    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("r", "refresh", "Refresh"),
        Binding("t", "tab('topology')", "Topo"),
        Binding("i", "tab('interfaces')", "Ifaces"),
        Binding("s", "tab('sockets')", "Sockets"),
        Binding("c", "tab('connections')", "Conns"),
        Binding("p", "tab('processes')", "Procs"),
        Binding("l", "tab('routes')", "Routes"),
        Binding("n", "tab('dns')", "DNS"),
        Binding("slash", "search", "Search", key_display="/"),
        Binding("f", "search", "Filter", show=False),
        Binding("space", "pause", "Pause"),
        Binding("d", "todo('Docker/Podman')", "Docker", show=False),
        Binding("w", "todo('Firewall')", "Firewall", show=False),
        Binding("h", "help", "Help"),
        Binding("escape", "escape", show=False),
    ]

    def __init__(self, interval: float = 2.0) -> None:
        super().__init__()
        self.interval = interval
        self.snap: Snapshot | None = None
        self.paused = False
        self.filter_text = ""
        self.events: deque = deque(maxlen=50)
        self._last_event: dict = {}
        self._expanded: set[str] = set()
        self._seen: set[str] = set()
        self._building = False
        self._busy = False
        self._rowrefs: dict[str, dict[str, tuple]] = {}

    # ---------- layout ----------
    def compose(self) -> ComposeResult:
        yield Static(id="header")
        with Horizontal(id="main"):
            with TabbedContent(initial="topology", id="tabs"):
                with TabPane("Topology", id="topology"):
                    yield Tree("host", id="topo")
                for name in ("interfaces", "sockets", "connections", "processes", "routes"):
                    with TabPane(name.capitalize(), id=name):
                        yield DataTable(id=f"t-{name}", cursor_type="row", zebra_stripes=True)
                with TabPane("DNS", id="dns"):
                    yield Static(id="dns-body")
            yield Static(id="details")
        yield Input(placeholder="фильтр (Enter — применить, Esc — сбросить)", id="filter")
        yield Static(id="events")
        yield Static(id="summary")
        yield Footer()

    def _q(self, selector, widget_type=None):
        # всегда ищем на базовом экране, даже если сверху открыта модалка (справка)
        base = self.screen_stack[0]
        return base.query_one(selector, widget_type) if widget_type else base.query_one(selector)

    def on_mount(self) -> None:
        self.call_after_refresh(self._start)

    def _start(self) -> None:
        for name, fn in T.TABLES.items():
            cols, _ = fn(_Empty)
            self._q(f"#t-{name}", DataTable).add_columns(*cols)
        self._q("#topo", Tree).show_root = True
        self._layout()
        self._draw_chrome()
        self.action_refresh()
        self.set_interval(self.interval, self._tick)
        self.set_interval(1, self._draw_chrome)

    def on_resize(self) -> None:
        self._layout()

    def _layout(self) -> None:
        main = self._q("#main")
        main.set_class(self.size.width < NARROW, "narrow")

    # ---------- collection ----------
    def _tick(self) -> None:
        if not self.paused:
            self.action_refresh()

    def action_refresh(self) -> None:
        if self._busy:
            return
        self._busy = True
        prev = self.snap
        self.run_worker(lambda: self._collect(prev), thread=True, exclusive=True)

    def _collect(self, prev) -> None:
        try:
            snap = collect_all(prev)
        except Exception as e:  # collector не должен ронять TUI
            self.call_from_thread(self.notify, f"collect error: {e}", severity="error")
            self._busy = False
            return
        self.call_from_thread(self._apply, snap)

    def _apply(self, snap: Snapshot) -> None:
        old = self.snap
        self.snap = snap
        self._busy = False
        if old is not None:
            self._diff_events(old, snap)
        for name, fn in T.TABLES.items():
            self._fill_table(name, fn(snap))
        self._fill_tree(build_topology(snap))
        self._q("#dns-body", Static).update(dns_view(snap))
        self._draw_chrome()
        self._update_details()

    # ---------- events (с защитой от спама) ----------
    def _diff_events(self, old: Snapshot, new: Snapshot) -> None:
        def keys(s: Snapshot):
            return {(x.proto, x.ip, x.port): x for x in s.listeners}
        a, b = keys(old), keys(new)
        now = time.time()

        def emit(kind: str, k, sock, snap) -> None:
            last = self._last_event.get((k, kind), 0)
            if now - last < 10:
                return
            self._last_event[(k, kind)] = now
            p = snap.processes.get(sock.pid) if sock.pid else None
            who = f"{p.name} PID {p.pid}" if p else "owner N/A"
            self.events.append((now, kind, f"{fmt_addr(k[1], k[2])}/{k[0]}  {who}"))

        for k in b.keys() - a.keys():
            emit("new", k, b[k], new)
        for k in a.keys() - b.keys():
            emit("closed", k, a[k], old)

    # ---------- tables ----------
    def _fill_table(self, name: str, data) -> None:
        _, rows = data
        table = self._q(f"#t-{name}", DataTable)
        cur = None
        try:
            if table.row_count:
                cur = table.coordinate_to_cell_key(table.cursor_coordinate).row_key.value
        except Exception:
            pass
        needle = self.filter_text.lower()
        refs: dict[str, tuple] = {}
        table.clear()
        seen: set[str] = set()
        for key, cells, kind, ref in rows:
            if needle and needle not in " ".join(cells).lower():
                continue
            k = key
            while k in seen:
                k += "'"
            seen.add(k)
            table.add_row(*cells, key=k)
            refs[k] = (kind, ref)
        self._rowrefs[name] = refs
        if cur in refs:
            table.move_cursor(row=table.get_row_index(cur), animate=False)

    # ---------- tree ----------
    def _fill_tree(self, root) -> None:
        tree = self._q("#topo", Tree)
        cur = tree.cursor_node.data.id if tree.cursor_node is not None and tree.cursor_node.data else None
        target = None
        self._building = True
        tree.clear()
        tree.root.data = root
        tree.root.set_label(node_label(root))

        def add(parent, n):
            nonlocal target
            if n.children:
                if n.id not in self._seen:
                    self._seen.add(n.id)
                    self._expanded.add(n.id)
                tn = parent.add(node_label(n), data=n, expand=n.id in self._expanded)
                for c in n.children:
                    add(tn, c)
            else:
                tn = parent.add_leaf(node_label(n), data=n)
            if cur and n.id == cur:
                target = tn

        for c in root.children:
            add(tree.root, c)
        tree.root.expand()
        self._building = False
        if target is not None:
            self.call_after_refresh(self._restore_cursor, tree, target)

    def _restore_cursor(self, tree, node) -> None:
        try:
            tree.move_cursor(node)
        except Exception:
            pass

    def on_tree_node_expanded(self, e: Tree.NodeExpanded) -> None:
        if not self._building and e.node.data:
            self._expanded.add(e.node.data.id)

    def on_tree_node_collapsed(self, e: Tree.NodeCollapsed) -> None:
        if not self._building and e.node.data:
            self._expanded.discard(e.node.data.id)

    # ---------- details ----------
    def _current(self):
        tab = self._q("#tabs", TabbedContent).active
        if tab == "topology":
            n = self._q("#topo", Tree).cursor_node
            d = n.data if n is not None else None
            return (d.kind, d.ref) if d else (None, None)
        if tab in self._rowrefs:
            table = self._q(f"#t-{tab}", DataTable)
            try:
                key = table.coordinate_to_cell_key(table.cursor_coordinate).row_key.value
                return self._rowrefs[tab].get(key, (None, None))
            except Exception:
                return (None, None)
        return (None, None)

    def _update_details(self) -> None:
        kind, ref = self._current()
        self._q("#details", Static).update(render_details(kind, ref, self.snap))

    def on_tree_node_highlighted(self, e) -> None:
        self._update_details()

    def on_data_table_row_highlighted(self, e) -> None:
        self._update_details()

    def on_tree_node_selected(self, e) -> None:
        self._q("#main").add_class("show")

    def on_data_table_row_selected(self, e) -> None:
        self._q("#main").add_class("show")

    def on_tabbed_content_tab_activated(self, e) -> None:
        self.call_after_refresh(self._focus_active)
        self._update_details()

    def _focus_active(self) -> None:
        tab = self._q("#tabs", TabbedContent).active
        wid = {"topology": "#topo", "dns": None}.get(tab, f"#t-{tab}")
        if wid:
            self._q(wid).focus()

    # ---------- chrome ----------
    def _draw_chrome(self) -> None:
        try:
            self._draw_chrome_inner()
        except NoMatches:
            pass

    def _draw_chrome_inner(self) -> None:
        self._q("#header", Static).update(header_text(self.snap, self.paused, self.interval, self.size.width))
        self._q("#summary", Static).update(summary_text(self.snap))
        ev = events_text(self.events)
        if self.snap and self.snap.notes and not self.events:
            ev = ev.__class__(" " + self.snap.notes[0], style="yellow")
        self._q("#events", Static).update(ev)

    # ---------- actions ----------
    def action_tab(self, name: str) -> None:
        self._q("#tabs", TabbedContent).active = name

    def action_search(self) -> None:
        f = self._q("#filter", Input)
        f.add_class("on")
        f.focus()

    def on_input_submitted(self, e: Input.Submitted) -> None:
        self.filter_text = e.value.strip()
        self._reapply()
        self._focus_active()

    def action_escape(self) -> None:
        f = self._q("#filter", Input)
        if f.has_class("on"):
            f.remove_class("on")
            f.value = ""
            self.filter_text = ""
            self._reapply()
            self._focus_active()
        self._q("#main").remove_class("show")

    def _reapply(self) -> None:
        if self.snap:
            for name, fn in T.TABLES.items():
                self._fill_table(name, fn(self.snap))

    def action_pause(self) -> None:
        self.paused = not self.paused
        self._draw_chrome()

    def action_todo(self, what: str) -> None:
        self.notify(f"{what}: пока не реализовано (см. roadmap)", severity="warning")

    def action_help(self) -> None:
        self.push_screen(HelpScreen())


class _Empty:
    """Пустой снимок, чтобы получить заголовки колонок."""
    interfaces = listeners = connections = routes = []
    processes: dict = {}
