from __future__ import annotations

from rich.text import Text
from rich.tree import Tree as RichTree

from netmap.topology.graph import Node


def node_label(n: Node) -> Text:
    t = Text()
    t.append(n.label, style=n.style or "")
    if n.meta:
        t.append("   ")
        t.append(n.meta, style="dim")
    return t


def to_rich_tree(root: Node) -> RichTree:
    """Статическое дерево для --watch и обычного вывода."""
    def walk(n: Node, parent: RichTree):
        b = parent.add(node_label(n))
        for c in n.children:
            walk(c, b)
    tree = RichTree(node_label(root))
    for c in root.children:
        walk(c, tree)
    return tree
