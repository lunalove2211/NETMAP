from __future__ import annotations
import time

from rich.text import Text

from netmap.snapshot import Snapshot


def header_text(snap: Snapshot | None, paused: bool, interval: float, width: int) -> Text:
    t = Text()
    t.append(" NETMAP ", style="bold reverse")
    if snap:
        t.append(f"  {snap.hostname}", style="bold")
        t.append(f"  {time.strftime('%H:%M:%S', time.localtime(snap.ts))}", style="dim")
        if not snap.is_root:
            t.append("  [no root: limited]", style="yellow")
    if paused:
        t.append("  ‖ PAUSED", style="bold yellow")
    else:
        t.append("  ● LIVE", style="bold green")
        t.append(f" refresh {interval:g}s", style="dim")
    return t


def summary_text(snap: Snapshot | None) -> Text:
    if not snap:
        return Text(" collecting…", style="dim")
    parts = [("Interfaces", len(snap.interfaces)), ("Listening", len(snap.listeners)),
             ("Connections", len(snap.connections)), ("Processes", len(snap.processes)), ("Routes", len(snap.routes))]
    t = Text(" ")
    for i, (k, v) in enumerate(parts):
        if i:
            t.append(" │ ", style="dim")
        t.append(f"{k} ")
        t.append(str(v), style="bold")
    return t


def events_text(events) -> Text:
    t = Text()
    if not events:
        t.append(" no socket changes yet", style="dim")
        return t
    for n, (ts, kind, msg) in enumerate(list(events)[-2:]):
        if n:
            t.append("\n")
        stamp = time.strftime("%H:%M:%S", time.localtime(ts))
        if kind == "new":
            t.append(f" {stamp} ⚠ NEW SOCKET  ", style="bold yellow")
        else:
            t.append(f" {stamp} ● SOCKET CLOSED  ", style="bold")
        t.append(msg)
    return t


def dns_view(snap: Snapshot):
    from rich.console import Group
    d = snap.dns
    lines = [Text("DNS", style="bold"), Text(f"resolver: {d['mode']}", style="cyan")]
    if d.get("stub"):
        lines.append(Text(f"stub: {d['stub']}", style="dim"))
    for ns in d["nameservers"]:
        lines.append(Text(f"  ├── {ns}"))
    if not d["nameservers"]:
        lines.append(Text("  N/A", style="dim"))
    if d.get("note"):
        lines.append(Text(d["note"], style="yellow"))
    if d["search"]:
        lines.append(Text("search: " + " ".join(d["search"]), style="dim"))
    lines += [Text(""), Text(f"hostname: {d['hostname']}", style="bold"), Text("/etc/hosts", style="dim")]
    for h in d.get("hosts", [])[:8]:
        lines.append(Text("  " + h, style="dim"))
    return Group(*lines)
