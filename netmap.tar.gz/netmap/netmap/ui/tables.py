"""Описание таблиц. Используется и в TUI, и в обычном CLI-выводе."""
from __future__ import annotations

from netmap.snapshot import Snapshot
from netmap.util import NA, fmt_addr, human_bytes, human_rate

# (title, columns, rows) ; row = (key, cells, kind, ref)


def _pname(snap: Snapshot, pid: int | None) -> str:
    if pid is None:
        return "N/A"
    p = snap.processes.get(pid)
    return f"{p.name} [{pid}]" if p else f"[{pid}]"


def interfaces(snap: Snapshot):
    cols = ["Name", "State", "IPv4", "IPv6", "MAC", "MTU", "RX", "TX", "RX rate", "TX rate"]
    rows = []
    for i in snap.interfaces:
        name = i.name + (" *" if i.is_default else "")
        rows.append((i.name, [name, i.state, ", ".join(i.ipv4) or "-", ", ".join(i.ipv6[:1]) or "-",
                              i.mac or "-", str(i.mtu or NA), human_bytes(i.rx_bytes), human_bytes(i.tx_bytes),
                              human_rate(i.rx_rate), human_rate(i.tx_rate)], "interface", i))
    return cols, rows


def sockets(snap: Snapshot):
    cols = ["Proto", "Local address", "State", "Process", "User", "Service"]
    rows = []
    for s in snap.listeners:
        p = snap.processes.get(s.pid) if s.pid else None
        rows.append((f"{s.proto}|{s.ip}|{s.port}|{s.pid}",
                     [s.proto, fmt_addr(s.ip, s.port), s.state, _pname(snap, s.pid),
                      (p.user if p else None) or NA, (p.service if p else None) or "-"], "socket", s))
    return cols, rows


def connections(snap: Snapshot):
    cols = ["Proto", "Local", "Remote", "State", "Process"]
    rows = []
    for c in snap.connections:
        rows.append((f"{c.proto}|{c.lip}|{c.lport}|{c.rip}|{c.rport}|{c.pid}",
                     [c.proto, fmt_addr(c.lip, c.lport), fmt_addr(c.rip, c.rport), c.state, _pname(snap, c.pid)],
                     "connection", c))
    return cols, rows


def processes(snap: Snapshot):
    cols = ["PID", "Name", "User", "Service", "Memory", "Executable"]
    rows = []
    for p in sorted(snap.processes.values(), key=lambda x: x.pid):
        rows.append((str(p.pid), [str(p.pid), p.name, p.user or NA, p.service or "-", human_bytes(p.rss),
                                  p.exe or NA], "process", p.pid))
    return cols, rows


def routes(snap: Snapshot):
    cols = ["Destination", "Gateway", "Interface", "Metric", "Family"]
    rows = []
    for r in snap.routes:
        rows.append((f"{r.dst}|{r.gateway}|{r.iface}|{r.metric}",
                     [r.dst, r.gateway or "direct", r.iface, str(r.metric), r.family], "route", r))
    return cols, rows


TABLES = {
    "interfaces": interfaces,
    "sockets": sockets,
    "connections": connections,
    "processes": processes,
    "routes": routes,
}
