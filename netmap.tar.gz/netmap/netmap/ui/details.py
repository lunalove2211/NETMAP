"""Панель Details: превращает выбранный объект в Rich-таблицу."""
from __future__ import annotations

from rich.console import Group
from rich.table import Table
from rich.text import Text

from netmap.snapshot import Snapshot
from netmap.topology.graph import ListenerGroup
from netmap.util import NA, bar, fmt_addr, human_age, human_bytes, human_rate


def _grid(title: str, rows: list[tuple[str, str]], subtitle: str | None = None):
    t = Table.grid(padding=(0, 2))
    t.add_column(style="dim", no_wrap=True)
    t.add_column(overflow="fold")
    for k, v in rows:
        t.add_row(k, v if v else NA)
    head = Text(title, style="bold")
    parts = [head, Text("─" * max(8, len(title)), style="dim"), t]
    if subtitle:
        parts.append(Text(subtitle, style="dim italic"))
    return Group(*parts)


def _proc_rows(snap: Snapshot, pid: int | None) -> list[tuple[str, str]]:
    if pid is None:
        return [("PID", "N/A (нужен root или сокет принадлежит ядру)")]
    p = snap.processes.get(pid)
    if not p:
        return [("PID", f"{pid} (процесс исчез или недоступен)")]
    return [("PID", str(p.pid)), ("User", p.user or NA), ("Service", p.service or "нет (не systemd-юнит)"),
            ("Executable", p.exe or NA), ("Command", (p.cmdline or NA)[:160]), ("Memory", human_bytes(p.rss)),
            ("Started", human_age(p.started))]


def render_details(kind: str | None, ref, snap: Snapshot | None):
    if snap is None or kind is None:
        return Text("Выбери элемент слева", style="dim")

    if kind == "listener" and isinstance(ref, ListenerGroup):
        g = ref
        rows = [("Port", f":{g.port}/{g.proto}"), ("Bound to", ", ".join(g.addrs))]
        if g.pids:
            rows += _proc_rows(snap, g.pids[0])
            if len(g.pids) > 1:
                rows.append(("Also PIDs", ", ".join(map(str, g.pids[1:8])) + (" …" if len(g.pids) > 8 else "")))
        else:
            rows += _proc_rows(snap, None)
        rows.append(("Connections", str(g.established)))
        if g.remotes:
            rows.append(("Clients", "\n".join(g.remotes[:6]) + (f"\n… +{len(g.remotes) - 6}" if len(g.remotes) > 6 else "")))
        if g.upstreams:
            rows.append(("Connects to", "\n".join(g.upstreams)))
        return _grid(f":{g.port}/{g.proto}", rows,
                     "связь «→» взята из живых соединений процесса, не из конфига")

    if kind == "interface":
        i = ref
        rows = [("State", i.state), ("Type", i.kind), ("IPv4", "\n".join(i.ipv4) or "-"),
                ("IPv6", "\n".join(i.ipv6) or "-"), ("MAC", i.mac or "-"), ("MTU", str(i.mtu or NA)),
                ("RX total", human_bytes(i.rx_bytes)), ("TX total", human_bytes(i.tx_bytes))]
        if i.is_default:
            rows.append(("Default route", f"via {i.gateway or 'direct'}"))
        sub = None
        if i.rx_rate is not None:
            if i.speed_mbps:
                cap = i.speed_mbps * 1e6 / 8
                rows.append(("RX", f"{bar(i.rx_rate / cap)} {human_rate(i.rx_rate)}"))
                rows.append(("TX", f"{bar(i.tx_rate / cap)} {human_rate(i.tx_rate)}"))
            else:
                rows.append(("RX rate", human_rate(i.rx_rate)))
                rows.append(("TX rate", human_rate(i.tx_rate)))
                sub = "скорость линка неизвестна — шкала не рисуется"
        return _grid(i.name, rows, sub)

    if kind == "process":
        pid = ref
        p = snap.processes.get(pid)
        return _grid(p.name if p else f"pid {pid}", _proc_rows(snap, pid))

    if kind == "socket":
        s = ref
        return _grid(fmt_addr(s.ip, s.port), [("Proto", s.proto), ("State", s.state)] + _proc_rows(snap, s.pid))

    if kind == "connection":
        c = ref
        rows = [("Proto", c.proto), ("State", c.state), ("Local", fmt_addr(c.lip, c.lport)),
                ("Remote", fmt_addr(c.rip, c.rport))] + _proc_rows(snap, c.pid)
        return _grid("connection", rows, "трафик по соединению без eBPF недоступен — не показываем")

    if kind == "route":
        r = ref
        return _grid(r.dst, [("Gateway", r.gateway or "direct"), ("Interface", r.iface), ("Metric", str(r.metric)),
                             ("Family", r.family)])

    if kind == "internet":
        rows = []
        for i in ref or []:
            rows.append((i.name, f"{', '.join(i.ipv4 + i.ipv6[:1]) or 'no ip'}\ngw {i.gateway or '-'}"))
        return _grid("INTERNET", rows or [("", "нет внешних интерфейсов")],
                     "firewall в MVP не анализируется: порт на 0.0.0.0 может быть закрыт фильтром")

    return Text("Нет деталей для этого узла", style="dim")
