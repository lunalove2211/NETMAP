from __future__ import annotations

from textual.screen import ModalScreen
from textual.widgets import Static

HELP = """[b]NetMap — горячие клавиши[/b]

 T  topology        I  interfaces      S  sockets
 C  connections     P  processes       L  routes
 N  DNS             R  refresh now     Space  pause/resume
 /  или F  фильтр таблиц (Esc — сбросить)
 Enter  детали (на узком терминале)
 ↑ ↓ ← →  навигация, Enter на узле дерева — свернуть/развернуть
 D  Docker/Podman и W  Firewall — пока не реализованы (roadmap)
 H  эта справка      Q  выход

NetMap только читает данные: ничего не меняет и никуда не отправляет.

[dim]нажми любую клавишу[/dim]"""


class HelpScreen(ModalScreen):
    DEFAULT_CSS = """
    HelpScreen { align: center middle; }
    HelpScreen > Static { width: 66; padding: 1 2; border: round $primary; background: $surface; }
    """

    def compose(self):
        yield Static(HELP)

    def on_key(self, event) -> None:
        event.stop()
        self.dismiss()
