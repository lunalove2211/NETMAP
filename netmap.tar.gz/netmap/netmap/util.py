from __future__ import annotations
import ipaddress
import time

NA = "N/A"


def human_bytes(n: int | float | None) -> str:
    if n is None:
        return NA
    n = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return NA


def human_rate(bytes_per_s: float | None) -> str:
    if bytes_per_s is None:
        return NA
    bits = bytes_per_s * 8
    if bits >= 1e9:
        return f"{bits / 1e9:.2f} Gbps"
    if bits >= 1e6:
        return f"{bits / 1e6:.1f} Mbps"
    if bits >= 1e3:
        return f"{bits / 1e3:.1f} Kbps"
    return f"{bits:.0f} bps"


def human_age(ts: float | None) -> str:
    if not ts:
        return NA
    s = max(0, int(time.time() - ts))
    d, s = divmod(s, 86400)
    h, s = divmod(s, 3600)
    m, s = divmod(s, 60)
    if d:
        return f"{d}d {h}h ago"
    if h:
        return f"{h}h {m}m ago"
    if m:
        return f"{m}m ago"
    return f"{s}s ago"


def bar(ratio: float, width: int = 14) -> str:
    ratio = min(max(ratio, 0.0), 1.0)
    full = round(ratio * width)
    return "█" * full + "░" * (width - full)


def _ip(ip: str):
    try:
        return ipaddress.ip_address(ip.split("%")[0])
    except ValueError:
        return None


def is_wildcard(ip: str) -> bool:
    return ip in ("0.0.0.0", "::", "")


def is_loopback(ip: str) -> bool:
    a = _ip(ip)
    if a is None:
        return False
    if a.version == 6 and a.ipv4_mapped:
        a = a.ipv4_mapped
    return a.is_loopback


def is_public(ip: str) -> bool:
    a = _ip(ip)
    return bool(a and a.is_global)


def fmt_addr(ip: str, port: int) -> str:
    return f"[{ip}]:{port}" if ":" in ip else f"{ip}:{port}"
