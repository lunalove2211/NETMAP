from __future__ import annotations
from dataclasses import dataclass


@dataclass
class Process:
    pid: int
    name: str
    user: str | None = None
    exe: str | None = None
    cmdline: str | None = None
    service: str | None = None
    rss: int | None = None
    started: float | None = None
