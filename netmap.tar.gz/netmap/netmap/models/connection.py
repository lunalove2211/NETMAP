from __future__ import annotations
from dataclasses import dataclass


@dataclass
class Connection:
    proto: str
    family: str
    lip: str
    lport: int
    rip: str
    rport: int
    state: str
    pid: int | None = None
