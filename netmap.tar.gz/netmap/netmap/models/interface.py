from __future__ import annotations
from dataclasses import dataclass, field


@dataclass
class Interface:
    name: str
    state: str
    kind: str = "physical"          # loopback / bridge / virtual / physical
    mac: str | None = None
    mtu: int | None = None
    speed_mbps: int | None = None   # None, если драйвер не отдаёт скорость
    ipv4: list[str] = field(default_factory=list)   # "1.2.3.4/24"
    ipv6: list[str] = field(default_factory=list)
    rx_bytes: int | None = None
    tx_bytes: int | None = None
    rx_rate: float | None = None    # байт/с, считается между двумя снимками
    tx_rate: float | None = None
    is_default: bool = False
    gateway: str | None = None
