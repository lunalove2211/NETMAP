from __future__ import annotations
from dataclasses import dataclass


@dataclass
class Socket:
    """Слушающий сокет (TCP LISTEN или UDP без remote)."""
    proto: str            # tcp / udp
    family: str           # ipv4 / ipv6
    ip: str
    port: int
    state: str            # LISTEN / BOUND
    pid: int | None = None
