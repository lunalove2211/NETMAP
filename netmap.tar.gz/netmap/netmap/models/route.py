from __future__ import annotations
from dataclasses import dataclass


@dataclass
class Route:
    dst: str
    gateway: str | None
    iface: str
    metric: int
    family: str = "ipv4"
