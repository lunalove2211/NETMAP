"""Таблица маршрутизации из /proc/net/route и /proc/net/ipv6_route (без subprocess)."""
from __future__ import annotations
import ipaddress
import socket
import struct

from netmap.models.route import Route


def _hex_ip4(h: str) -> str:
    return socket.inet_ntoa(struct.pack("<L", int(h, 16)))


def _read(path: str) -> list[str]:
    try:
        with open(path) as f:
            return f.read().splitlines()[1:]
    except OSError:
        return []


def _ipv4() -> list[Route]:
    out = []
    for line in _read("/proc/net/route"):
        p = line.split()
        if len(p) < 8:
            continue
        iface, dst, gw, flags, metric, mask = p[0], p[1], p[2], int(p[3], 16), int(p[6]), p[7]
        if not flags & 0x1:  # RTF_UP
            continue
        prefix = bin(int(mask, 16)).count("1")
        gateway = _hex_ip4(gw) if flags & 0x2 else None
        out.append(Route(f"{_hex_ip4(dst)}/{prefix}", gateway, iface, metric))
    return out


def _ipv6() -> list[Route]:
    out = []
    for line in _read("/proc/net/ipv6_route"):
        p = line.split()
        if len(p) < 10:
            continue
        dst, plen, nh, metric, flags, iface = p[0], int(p[1], 16), p[4], int(p[5], 16), int(p[8], 16), p[9]
        if flags & 0x0200 or flags & 0x80000000 or iface == "lo":  # reject / local
            continue
        d = ipaddress.IPv6Address(bytes.fromhex(dst))
        if d.is_link_local or d.is_multicast:
            continue
        gw = ipaddress.IPv6Address(bytes.fromhex(nh))
        out.append(Route(f"{d}/{plen}", None if gw.is_unspecified else str(gw), iface, metric, "ipv6"))
    return out


def collect_routes() -> list[Route]:
    return sorted(_ipv4() + _ipv6(), key=lambda r: (r.family, r.dst != "0.0.0.0/0", r.metric))
