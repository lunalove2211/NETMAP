"""DNS: /etc/resolv.conf (+ реальные upstream-ы systemd-resolved, если есть)."""
from __future__ import annotations
import os


def _parse(path: str) -> tuple[list[str], list[str]]:
    ns, search = [], []
    try:
        with open(path) as f:
            for line in f:
                p = line.split()
                if len(p) >= 2 and p[0] == "nameserver":
                    ns.append(p[1])
                elif len(p) >= 2 and p[0] in ("search", "domain"):
                    search += p[1:]
    except OSError:
        pass
    return ns, search


def collect_dns() -> dict:
    ns, search = _parse("/etc/resolv.conf")
    info = {"mode": "resolv.conf", "nameservers": ns, "search": search, "stub": None, "note": None}
    if any(n in ("127.0.0.53", "127.0.0.54") for n in ns):
        info["mode"] = "systemd-resolved"
        info["stub"] = ns[0]
        real, real_search = _parse("/run/systemd/resolve/resolv.conf")
        if real:
            info["nameservers"], info["search"] = real, real_search or search
        else:
            info["note"] = "upstream-серверы не прочитаны (/run/systemd/resolve/resolv.conf недоступен)"
    elif ns and all(n.startswith("127.") or n == "::1" for n in ns):
        info["mode"] = "local resolver"
    hosts = []
    try:
        with open("/etc/hosts") as f:
            for line in f:
                line = line.split("#")[0].strip()
                if line:
                    hosts.append(line)
    except OSError:
        pass
    info["hosts"] = hosts
    info["hostname"] = os.uname().nodename
    return info
