"""Информация о процессах по PID. Всё, что недоступно, остаётся None."""
from __future__ import annotations
import re

import psutil

from netmap.models.process import Process

_SERVICE_RE = re.compile(r"([^/]+\.service)(?:/|$)")


def _try(fn, default=None):
    try:
        return fn()
    except (psutil.Error, OSError, KeyError, ValueError):
        return default


def _service(pid: int) -> str | None:
    """Ищем *.service в cgroup процесса. Работает с systemd, без него вернёт None."""
    try:
        with open(f"/proc/{pid}/cgroup") as f:
            data = f.read()
    except OSError:
        return None
    found = _SERVICE_RE.findall(data)
    return found[-1] if found else None


def collect_processes(pids: set[int]) -> dict[int, Process]:
    out: dict[int, Process] = {}
    for pid in pids:
        try:
            p = psutil.Process(pid)
            with p.oneshot():
                name = p.name()
                user = _try(p.username) or str(_try(lambda: p.uids().real, "?"))
                exe = _try(p.exe) or None
                cmd = " ".join(_try(p.cmdline, []) or []) or None
                rss = _try(lambda: p.memory_info().rss)
                started = _try(p.create_time)
        except psutil.Error:
            continue  # процесс успел умереть
        out[pid] = Process(pid, name, user, exe, cmd, _service(pid), rss, started)
    return out
