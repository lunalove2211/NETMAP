"""Сетевые интерфейсы: /sys/class/net + psutil."""
from __future__ import annotations
import ipaddress
import os
import socket

import psutil

from netmap.models.interface import Interface
from netmap.models.route import Route

SYS = "/sys/class/net"


def _read(path: str) -> str | None:
    try:
        with open(path) as f:
            return f.read().strip()
    except OSError:
        return None


def _kind(name: str) -> str:
    if name == "lo":
        return "loopback"
    base = os.path.join(SYS, name)
    if os.path.isdir(os.path.join(base, "bridge")):
        return "bridge"
    if not os.path.exists(os.path.join(base, "device")):
        return "virtual"
    return "physical"


def _prefix6(mask: str | None) -> int | None:
    if not mask:
        return None
    try:
        return bin(int(ipaddress.IPv6Address(mask.split("/")[0])) ).count("1")
    except ValueError:
        return None


def collect_interfaces(routes: list[Route]) -> list[Interface]:
    addrs = psutil.net_if_addrs()
    stats = psutil.net_if_stats()
    io = psutil.net_io_counters(pernic=True)
    default = next((r for r in routes if r.dst == "0.0.0.0/0" and r.family == "ipv4"), None)
    if default is None:
        default = next((r for r in routes if r.dst == "::/0"), None)

    out = []
    for name in sorted(addrs):
        iface = Interface(name=name, state=_read(f"{SYS}/{name}/operstate") or "unknown", kind=_kind(name))
        if iface.state == "unknown" and name in stats:
            iface.state = "up" if stats[name].isup else "down"
        iface.state = iface.state.upper()
        for a in addrs[name]:
            if a.family == socket.AF_INET:
                try:
                    pl = ipaddress.IPv4Network(f"0.0.0.0/{a.netmask}").prefixlen
                except ValueError:
                    pl = 32
                iface.ipv4.append(f"{a.address}/{pl}")
            elif a.family == socket.AF_INET6:
                pl = _prefix6(a.netmask)
                iface.ipv6.append(f"{a.address.split('%')[0]}/{pl}" if pl is not None else a.address.split("%")[0])
            elif a.family == psutil.AF_LINK and a.address and a.address != "00:00:00:00:00:00":
                iface.mac = a.address
        if name in stats:
            iface.mtu = stats[name].mtu
        sp = _read(f"{SYS}/{name}/speed")
        if sp and sp.lstrip("-").isdigit() and int(sp) > 0:
            iface.speed_mbps = int(sp)
        if name in io:
            iface.rx_bytes, iface.tx_bytes = io[name].bytes_recv, io[name].bytes_sent
        if default and default.iface == name:
            iface.is_default, iface.gateway = True, default.gateway
        out.append(iface)
    return out
