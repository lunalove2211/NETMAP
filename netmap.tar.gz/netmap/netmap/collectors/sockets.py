"""Слушающие сокеты и соединения через psutil (читает /proc/net/* и /proc/*/fd)."""
from __future__ import annotations
import socket

import psutil

from netmap.models.connection import Connection
from netmap.models.socket import Socket


def collect_sockets() -> tuple[list[Socket], list[Connection], str | None]:
    try:
        raw = psutil.net_connections(kind="inet")
    except (psutil.Error, OSError) as e:
        return [], [], f"sockets: {e}"

    listeners: list[Socket] = []
    conns: list[Connection] = []
    for c in raw:
        if not c.laddr or not c.laddr.port:
            continue
        proto = "tcp" if c.type == socket.SOCK_STREAM else "udp"
        fam = "ipv6" if c.family == socket.AF_INET6 else "ipv4"
        if proto == "tcp" and c.status == psutil.CONN_LISTEN:
            listeners.append(Socket(proto, fam, c.laddr.ip, c.laddr.port, "LISTEN", c.pid))
        elif proto == "udp" and not c.raddr:
            listeners.append(Socket(proto, fam, c.laddr.ip, c.laddr.port, "BOUND", c.pid))
        elif c.raddr:
            state = c.status if proto == "tcp" else "CONNECTED"
            conns.append(Connection(proto, fam, c.laddr.ip, c.laddr.port, c.raddr.ip, c.raddr.port, state, c.pid))
    listeners.sort(key=lambda s: (s.proto, s.port, s.ip))
    return listeners, conns, None
