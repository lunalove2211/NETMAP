from netmap.cli import main

raise SystemExit(main())
