import time

from netmap.models.connection import Connection
from netmap.models.interface import Interface
from netmap.models.process import Process
from netmap.models.socket import Socket
from netmap.snapshot import Snapshot
from netmap.topology.builder import build_topology


def make_snap():
    ifaces = [Interface("eth0", "UP", ipv4=["203.0.113.5/24"], is_default=True, gateway="203.0.113.1"),
              Interface("lo", "UP", kind="loopback", ipv4=["127.0.0.1/8"])]
    listeners = [Socket("tcp", "ipv4", "0.0.0.0", 443, "LISTEN", 10),
                 Socket("tcp", "ipv4", "127.0.0.1", 8000, "LISTEN", 20)]
    conns = [Connection("tcp", "ipv4", "127.0.0.1", 40000, "127.0.0.1", 8000, "ESTABLISHED", 10),
             Connection("tcp", "ipv4", "203.0.113.5", 443, "198.51.100.7", 51000, "ESTABLISHED", 10)]
    procs = {10: Process(10, "nginx"), 20: Process(20, "uvicorn")}
    return Snapshot(time.time(), "test", True, ifaces, [], listeners, conns, procs, {})


def labels(n):
    yield n.label
    for c in n.children:
        yield from labels(c)


def test_proxy_edge_is_detected():
    root = build_topology(make_snap())
    inet = next(c for c in root.children if c.kind == "internet")
    https = inet.children[0]
    assert https.label.startswith(":443/tcp")
    assert [c.label.split()[0] for c in https.children] == [":8000/tcp"]


def test_nested_backend_not_duplicated_in_localhost():
    root = build_topology(make_snap())
    assert not any(c.id == "sec:local" for c in root.children)


def test_unknown_pid_is_not_guessed():
    s = make_snap()
    s.listeners[0].pid = None
    root = build_topology(s)
    assert any("owner unknown" in l for l in labels(root))
