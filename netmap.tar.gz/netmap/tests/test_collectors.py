from netmap.collectors.interfaces import collect_interfaces
from netmap.collectors.routes import collect_routes
from netmap.collectors.sockets import collect_sockets


def test_collectors_run_without_crashing():
    routes = collect_routes()
    assert isinstance(collect_interfaces(routes), list)
    listeners, conns, err = collect_sockets()
    assert err is None
